const User = require('./user-model');
const Room = require('./room-model');
const Location = require('./location-model');

module.exports = { User, Room, Location };