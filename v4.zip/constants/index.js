// var domain =
//   process.env.NODE_ENV === 'development' ? 'localhost' : '192.168.0.36';


var domain = '192.168.0.36';

// const publicIp = require('public-ip');

// var domain;
// const getDomain = async () => {
//   domain = await publicIp.v4();
// };

// getDomain();
module.exports = { domain };
