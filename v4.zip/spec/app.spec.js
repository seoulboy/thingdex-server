var expect = require('chai').expect;

describe('sample test', () => {
  it('test 1', () => {
    expect(3).to.equal(3);
  })
})